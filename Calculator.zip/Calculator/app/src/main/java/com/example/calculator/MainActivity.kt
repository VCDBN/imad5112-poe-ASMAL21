package com.example.calculator

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import kotlin.math.absoluteValue
import kotlin.math.pow

class MainActivity : AppCompatActivity() {
    private val numbers = mutableListOf<Int>()
    private lateinit var adapter: ArrayAdapter<Int>

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var textView = findViewById<TextView>(R.id.AnswerVuew)

        var input1 = findViewById<EditText>(R.id.input1)
        var input2 = findViewById<EditText>(R.id.input2)

        var addbt = findViewById<Button>(R.id.addbt)
        var minusbt = findViewById<Button>(R.id.minusbt)
        var timesbt = findViewById<Button>(R.id.timesbt)
        var dividebt = findViewById<Button>(R.id.dividebt)
        var squarerootbt = findViewById<Button>(R.id.squarerootbt)
        var powerbt = findViewById<Button>(R.id.powerbt)

        addbt.setOnClickListener {
            var answerdifference = input1.text.toString().toInt() + input2.text.toString().toInt()
            textView.text = answerdifference.toString()
        }
        minusbt.setOnClickListener {
            var answerdifference = input1.text.toString().toInt() - input2.text.toString().toInt()
            textView.text = answerdifference.toString()
        }
        timesbt.setOnClickListener {
            var answerdifference = input1.text.toString().toInt() * input2.text.toString().toInt()
            textView.text = answerdifference.toString()
        }

        dividebt.setOnClickListener {
            if (input2.text.toString().toInt() != 0) {
                var DifferenceStorage =
                    input1.text.toString().toInt() / input2.text.toString().toInt()
                textView.text = DifferenceStorage.toString()
            } else {
                textView.text = "Cant divide by zero"
            }

        }
        squarerootbt.setOnClickListener {
            var DifferenceStorage = Math.sqrt(input1.text.toString().toInt().toDouble())
            textView.text = DifferenceStorage.toString()

            val number = input1.text.toString().toDouble()

            if (number >= 0) {
                val result = Math.sqrt(number)
                textView.text = "sqrt($number) = $result"
            } else {
                val result = Math.sqrt(number.absoluteValue)
                textView.text = "sqrt($number) = ${result}i"
            }
        }

        powerbt.setOnClickListener {
            val base = input1.text.toString().toDouble()
            val exponent = input2.text.toString().toDouble()
            val result = base.pow(exponent)
            textView.text = "$base raised to the power of exponent is $result"
        }

        val numberInput = findViewById<EditText>(R.id.numberInput)
        val addButton = findViewById<Button>(R.id.addButton)
        val clearButton = findViewById<Button>(R.id.clearButton)
        val calculateAverageButton = findViewById<Button>(R.id.calculateAverageButton)
        val findMinMaxButton = findViewById<Button>(R.id.findMinMaxButton)
        val numbersListView = findViewById<ListView>(R.id.numbersListView)
        val averageTextView = findViewById<TextView>(R.id.averageTextView)
        val minMaxTextView = findViewById<TextView>(R.id.minMaxTextView)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, numbers)
        numbersListView.adapter = adapter

        addButton.setOnClickListener {
            val number = numberInput.text.toString().toIntOrNull()
            if (number != null && numbers.size < 10) {
                numbers.add(number)
                adapter.notifyDataSetChanged()
            }
            numberInput.text.clear()
        }

        clearButton.setOnClickListener {
            numbers.clear()
            adapter.notifyDataSetChanged()
        }

        calculateAverageButton.setOnClickListener {
            var sum = 0
            for (number in numbers) {
                sum += number
            }
            val average = sum.toDouble() / numbers.size
            averageTextView.text = "Average: $average"
        }

        findMinMaxButton.setOnClickListener {
            var min = numbers[0]
            var max = numbers[0]
            for (number in numbers) {
                if (number < min) {
                    min = number
                }
                if (number > max) {
                    max = number
                }
            }
            minMaxTextView.text = "Min: $min, Max: $max"
        }
    }
}
